const express = require("express"); //tabNIne
const router = express.Router();
const mysqlConnection = require("../../db/db.js");

// Producto
//Petición get
router.get("/producto/:restauranteId", (req, res) => {
  const { restauranteId } = req.params;
  console.log(restauranteId);
  mysqlConnection.query(
    "SELECT id, precio, nombre, id_restaurante, url_imagen FROM producto WHERE id_restaurante = ?",
    [restauranteId],
    (err, rows, fields) => {
      if (!err) {
        console.log(rows);

        res.status(200).json(rows);
      } else {
        console.log(err);
        res.status(500);
      }
    }
  );
});

module.exports = router;
