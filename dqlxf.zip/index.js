const express = require("express");
const app = express();
const cors = require("cors");

app.use(express.json());
app.use(cors());

const categoria = require("./src/routes/categoria.js");
const producto = require("./src/routes/producto.js");
const mesa = require("./src/routes/mesa.js");
const pedido = require("./src/routes/pedido.js");
const pedido_restaurante_menu = require("./src/routes/pedido_restaurante_menu.js");
const producto_pedido = require("./src/routes/producto_pedido.js");
const restaurante = require("./src/routes/restaurante.js");
const telefono = require("./src/routes/telefono.js");
const tipo_ciudad = require("./src/routes/tipo_ciudad.js");
const tipo_documento = require("./src/routes/tipo_documento.js");
const tipo_usuario = require("./src/routes/tipo_usuario.js");
const usuario = require("./src/routes/usuario.js");

app.use("/api", categoria);
app.use("/api", producto);
app.use("/api", mesa);
app.use("/api", pedido);
app.use("/api", pedido_restaurante_menu);
app.use("/api", producto_pedido);
app.use("/api", restaurante);
app.use("/api", telefono);
app.use("/api", tipo_ciudad);
app.use("/api", tipo_documento);
app.use("/api", tipo_usuario);
app.use("/api", usuario);

app.use(express.urlencoded({ extended: false }));

app.listen(3001, () => {
  console.log("server started");
});
