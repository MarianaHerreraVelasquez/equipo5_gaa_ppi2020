const mysql = require("mysql");
const mysqlConnection = mysql.createConnection({
  // db creada https://console.clever-cloud.com/
  host: "bbkuvl4r9hedilmrqtaf-mysql.services.clever-cloud.com",
  user: "ukokw6knh3vv6cpi",
  password: "4dSPLG21FholpTrVC7sS",
  database: "bbkuvl4r9hedilmrqtaf",
  multipleStatements: true
});

mysqlConnection.connect(function (err) {
  if (err) {
    console.error(err);
    return;
  } else {
    console.log("base de datos conectada");
  }
});
module.exports = mysqlConnection;
